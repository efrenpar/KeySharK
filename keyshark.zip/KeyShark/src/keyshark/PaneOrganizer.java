/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

/**
 *
 * @author Isa
 */
public class PaneOrganizer {
    private BorderPane root;
       
    
     public BorderPane getRoot() {
        return root;
    }
     
     public PaneOrganizer()
    {
    
        this.root = new BorderPane();
        HBox oceano = new HBox();
        Image image = new Image("/imagenes/Buzo.gif");
        ImageView buzo = new ImageView();
        buzo.setImage(image);
        oceano.getChildren().add(buzo);
        this.root.setCenter(oceano);
        
        
    }
}
