/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Isa
 */
public class Buzo implements Runnable {
    
    private ImageView Buzoimage;
    private double posicionY;
    private double posicionX;
    private int puntaje;
    private int vida;
    private int factorE;
    private double factorV;
    
    public Buzo(){
    
        this.Buzoimage.setImage(new Image("/imagenes/Buzo.gif"));
        this.vida = 3;
        this.factorE = 0;
        this.factorV = 0;
        this.puntaje = 0;
        
        
    }
    
    

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
