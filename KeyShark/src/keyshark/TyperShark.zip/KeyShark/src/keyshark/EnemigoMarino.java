/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Isa
 */
public  class  EnemigoMarino implements Runnable {
    
    private ImageView EMarineImage ;
    private double posicionX;
    private double posicionY;
    private int valorPuntaje;
    private double damageValue;
    private Label palabraOnEnemy;
    
    
    public EnemigoMarino(Image enemyImage,int puntaje,double damageValue){
    
        this.EMarineImage.setImage(enemyImage);
        this.valorPuntaje = puntaje;
        this.damageValue = damageValue;
    }
    
     @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void setPalabraEnemigoMarino(String palabra){
    
        this.palabraOnEnemy = new Label(palabra);
    }
}
