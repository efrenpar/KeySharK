/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.layout.Pane;

/**
 *
 * @author Isa
 */
public class Oceano {
    private Pane pane;
    private Buzo buzo;
    
    public Oceano(){
    
        this.pane = new Pane();
        this.buzo = new Buzo();
        
    }

    public Pane getPane() {
        return pane;
    }

    public void setPane(Pane pane) {
        this.pane = pane;
    }

    public Buzo getBuzo() {
        return buzo;
    }

    public void setBuzo(Buzo buzo) {
        this.buzo = buzo;
    }
    
    
    public void generarOceano(){
    
        this.pane.getChildren().add(this.buzo.getBuzoimage());
        this.buzo.getBuzoimage().setTranslateX(50);
        this.buzo.getBuzoimage().setTranslateX(50);
    }
}
