/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.image.Image;

/**
 *
 * @author Isa
 */
public class Pirania extends EnemigoMarino {
    
    
    public Pirania(){
    
        super(new Image("/Imagenes/pirania.png"),2,0.33);
        
    }
    
    public void generarPalabraPirania(){
    
        int num1 = 97;
        int num2 = 122;
        int numeroAleatorio = (int)Math.floor(Math.random()*(num2-num1)+num1);
        char car = (char)numeroAleatorio;
        String palabraPirania=""+car;
        super.setPalabraEnemigoMarino(palabraPirania);
    }
    
    
}
