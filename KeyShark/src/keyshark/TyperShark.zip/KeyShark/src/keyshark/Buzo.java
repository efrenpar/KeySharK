/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyshark;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Isa
 */
public class Buzo implements Runnable {
    
    private ImageView Buzoimage;
    private double posicionY;
    private double posicionX;
    private int puntaje;
    private double vida;
    
    public Buzo(){
    
        Image image = new Image("/Imagenes/Buzo.gif");
        this.Buzoimage.setImage(image);
        this.vida = 3;
        this.puntaje = 0; 
    }
    
    public void  contarPuntosDeDescenso(){
    
        this.puntaje++;
    }    
    
    public void contarPuntosDeAtaque(int valorEnemigo){
    
        this.puntaje =+ valorEnemigo;
    }

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ImageView getBuzoimage() {
        return Buzoimage;
    }
    
    
}
